package com.baseflow.flutter.plugin.geolocator;

import java.util.UUID;

public interface OnCompletionListener {
    void onCompletion(UUID taskID);
}
